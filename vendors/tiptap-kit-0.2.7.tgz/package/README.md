# @ikame-lib/tiptap-kit

Tiptap v3 React UI kit with templates and CLI scaffolding.

## Install

```bash
npm install @ikame-lib/tiptap-kit
```

## Quick Start

### Add a template to your project

```bash
npx tiptap-kit add simple
npx tiptap-kit add notion-like
npx tiptap-kit add chat-box
```

### Options

```bash
npx tiptap-kit add simple -t src/editor
npx tiptap-kit add simple --force
npx tiptap-kit add simple --skip-install
```

### Eject a component for deep customization

```bash
npx tiptap-kit eject button
```

### List available templates and components

```bash
npx tiptap-kit list
```

## Templates

- `chat-box` - Chat/comment input with emoji, mention, image upload, Enter to send
- `simple` - Toolbar + floating menus starter
- `notion-like` - Rich Notion-style with slash commands, table, emoji, AI menu

## Styling

Import once:

```ts
import "@ikame-lib/tiptap-kit/styles.css";
```

CSS variables: `--tt-primary`, `--tt-border`, `--tt-radius`, etc.

## Customization

Template files are copied to your project for full control.

For deeper customization, eject individual components:

```bash
npx tiptap-kit eject button
```
