import { Command } from "commander";
import { registerAddCommand } from "./cli/commands/add";
import { registerEjectCommand } from "./cli/commands/eject";
import { registerListCommand } from "./cli/commands/list";

const program = new Command();
program.name("tkit").description("@ikame-lib/tiptap-kit CLI").version("0.1.1");

registerAddCommand(program);
registerEjectCommand(program);
registerListCommand(program);

program.parse(process.argv);

