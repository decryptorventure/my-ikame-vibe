declare module "is-hotkey" {
  export function isHotkey(
    hotkey: string | string[],
    event: KeyboardEvent | { key?: string; code?: string }
  ): boolean
  export default isHotkey
}

