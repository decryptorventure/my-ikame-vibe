import fs from "fs";
import path from "path";

export interface CopyResult {
  created: string[];
  skipped: string[];
}

const normalize = (value: string) => value.replace(/\\/g, "/");

const getTargetRelativePath = (filePath: string, templateId: string) => {
  const normalized = normalize(filePath);
  const templatePrefix = `templates/${templateId}/`;
  const primitivePrefix = `src/components/tiptap-ui-primitive/${templateId}/`;

  if (normalized.startsWith(templatePrefix)) {
    return normalized.slice(templatePrefix.length);
  }

  if (normalized.startsWith(primitivePrefix)) {
    return normalized.slice(primitivePrefix.length);
  }

  return normalized;
};

export function copyTemplateFiles(
  files: string[],
  sourceBaseDir: string,
  targetBaseDir: string,
  templateId: string,
  force: boolean
): CopyResult {
  const result: CopyResult = {
    created: [],
    skipped: []
  };

  for (const file of files) {
    const normalizedSourceRelative = normalize(file);
    const targetRelative = getTargetRelativePath(normalizedSourceRelative, templateId);
    const sourcePath = path.resolve(sourceBaseDir, normalizedSourceRelative);
    const targetPath = path.resolve(targetBaseDir, targetRelative);

    if (!fs.existsSync(sourcePath)) {
      result.skipped.push(targetRelative);
      continue;
    }

    if (!force && fs.existsSync(targetPath)) {
      result.skipped.push(targetRelative);
      continue;
    }

    fs.mkdirSync(path.dirname(targetPath), { recursive: true });
    fs.copyFileSync(sourcePath, targetPath);
    result.created.push(targetRelative);
  }

  return result;
}
