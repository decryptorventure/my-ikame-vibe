import fs from "fs";
import path from "path";

const normalize = (value: string) => value.replace(/\\/g, "/");

const escapeRegExp = (value: string) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

const collectTsFiles = (dirPath: string, files: string[] = []) => {
  if (!fs.existsSync(dirPath)) {
    return files;
  }

  const entries = fs.readdirSync(dirPath, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dirPath, entry.name);
    if (entry.isDirectory()) {
      collectTsFiles(fullPath, files);
      continue;
    }

    if (entry.name.endsWith(".ts") || entry.name.endsWith(".tsx")) {
      files.push(fullPath);
    }
  }

  return files;
};

export function transformImportsInDir(
  dirPath: string,
  fromPattern: string,
  ejectTargetDir: string
): number {
  const files = collectTsFiles(dirPath);
  const importRegex = new RegExp(
    `from\\s+(['"])${escapeRegExp(fromPattern)}\\1`,
    "g"
  );
  let transformedCount = 0;

  for (const filePath of files) {
    const fileDir = path.dirname(filePath);
    let relativePath = normalize(path.relative(fileDir, ejectTargetDir));
    if (relativePath.length === 0) {
      relativePath = ".";
    } else if (!relativePath.startsWith(".")) {
      relativePath = `./${relativePath}`;
    }

    const original = fs.readFileSync(filePath, "utf8");
    const updated = original.replace(
      importRegex,
      (_, quote: string) => `from ${quote}${relativePath}${quote}`
    );

    if (updated !== original) {
      fs.writeFileSync(filePath, updated, "utf8");
      transformedCount += 1;
    }
  }

  return transformedCount;
}
