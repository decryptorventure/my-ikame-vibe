import fs from "fs";
import path from "path";
import type { Registry } from "../registry-types";

const getRegistryCandidates = () => [
  path.resolve(__dirname, "registry.json"),
  path.resolve(__dirname, "..", "..", "registry.json"),
  path.resolve(__dirname, "..", "registry.json"),
  path.resolve(process.cwd(), "dist", "registry.json"),
  path.resolve(process.cwd(), "registry", "registry.json")
];

export function loadRegistry(): Registry {
  for (const registryPath of getRegistryCandidates()) {
    if (!fs.existsSync(registryPath)) {
      continue;
    }

    const content = fs.readFileSync(registryPath, "utf8");
    return JSON.parse(content) as Registry;
  }

  throw new Error("Unable to locate registry.json");
}
