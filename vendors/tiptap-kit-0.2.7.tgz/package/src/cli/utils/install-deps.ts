import fs from "fs";
import path from "path";
import { execSync } from "child_process";
import { detectPackageManager } from "./detect-package-manager";

type PackageJsonShape = {
  dependencies?: Record<string, string>;
  devDependencies?: Record<string, string>;
};

export function installMissingDeps(
  requiredDeps: Record<string, string>,
  projectRoot: string,
  skipInstall: boolean
): void {
  const packageJsonPath = path.join(projectRoot, "package.json");
  const packageJson = JSON.parse(
    fs.readFileSync(packageJsonPath, "utf8")
  ) as PackageJsonShape;

  const installed = new Set([
    ...Object.keys(packageJson.dependencies ?? {}),
    ...Object.keys(packageJson.devDependencies ?? {})
  ]);

  const missing = Object.entries(requiredDeps).filter(([name]) => !installed.has(name));

  if (missing.length === 0) {
    console.log("All dependencies already installed");
    return;
  }

  const installArgs = missing.map(([name, version]) => `${name}@${version}`);

  if (skipInstall) {
    console.log(`\nMissing ${missing.length} dependencies (skipped install):`);
    for (const dep of installArgs) {
      console.log(`  - ${dep}`);
    }
    return;
  }

  console.log(`\nInstalling ${missing.length} dependencies...`);
  const packageManager = detectPackageManager(projectRoot);
  const commandByPackageManager: Record<typeof packageManager, string> = {
    npm: `npm install ${installArgs.join(" ")}`,
    yarn: `yarn add ${installArgs.join(" ")}`,
    pnpm: `pnpm add ${installArgs.join(" ")}`,
    bun: `bun add ${installArgs.join(" ")}`
  };

  execSync(commandByPackageManager[packageManager], {
    cwd: projectRoot,
    stdio: "inherit"
  });
}
