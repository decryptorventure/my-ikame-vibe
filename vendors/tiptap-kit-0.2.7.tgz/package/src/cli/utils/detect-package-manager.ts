import fs from "fs";
import path from "path";
import { execSync } from "child_process";

export type PackageManager = "npm" | "yarn" | "pnpm" | "bun";

function isCommandAvailable(cmd: string): boolean {
  try {
    execSync(`${cmd} --version`, { stdio: "ignore" });
    return true;
  } catch {
    return false;
  }
}

export function detectPackageManager(projectDir: string): PackageManager {
  const bunLockB = path.join(projectDir, "bun.lockb");
  const bunLock = path.join(projectDir, "bun.lock");
  const pnpmLock = path.join(projectDir, "pnpm-lock.yaml");
  const yarnLock = path.join(projectDir, "yarn.lock");

  if ((fs.existsSync(bunLockB) || fs.existsSync(bunLock)) && isCommandAvailable("bun")) {
    return "bun";
  }

  if (fs.existsSync(pnpmLock) && isCommandAvailable("pnpm")) {
    return "pnpm";
  }

  if (fs.existsSync(yarnLock) && isCommandAvailable("yarn")) {
    return "yarn";
  }

  return "npm";
}
