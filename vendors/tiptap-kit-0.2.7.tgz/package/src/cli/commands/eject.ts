import fs from "fs";
import path from "path";
import type { Command } from "commander";
import { loadRegistry } from "../utils/resolve-registry";
import { copyTemplateFiles } from "../utils/copy-files";
import { transformImportsInDir } from "../utils/transform-imports";

type EjectCommandOptions = {
  target: string;
  force: boolean;
};

const resolveSourceBaseDir = () => {
  const candidates = [
    __dirname,
    path.resolve(__dirname, ".."),
    path.resolve(__dirname, "..", ".."),
    process.cwd()
  ];

  for (const candidate of candidates) {
    const sourceDir = path.join(candidate, "src", "components", "tiptap-ui-primitive");
    if (fs.existsSync(sourceDir)) {
      return candidate;
    }
  }

  throw new Error("Cannot locate source directory for ejectable components");
};

export function registerEjectCommand(program: Command): void {
  program
    .command("eject")
    .argument("<component>", "Component id")
    .option("-t, --target <dir>", "Base target directory", "src/tiptap")
    .option("-f, --force", "Overwrite existing files", false)
    .action((componentId: string, options: EjectCommandOptions) => {
      const registry = loadRegistry();
      const ejectable = registry.ejectables[componentId];

      if (!ejectable) {
        const available = Object.keys(registry.ejectables).join(", ");
        console.error(`Unknown ejectable: ${componentId}`);
        console.error(`Available ejectables: ${available}`);
        process.exit(1);
      }

      const sourceBaseDir = resolveSourceBaseDir();
      const baseTargetDir = path.resolve(process.cwd(), options.target);
      const ejectTargetDir = path.resolve(baseTargetDir, ejectable.targetDir);

      const copyResult = copyTemplateFiles(
        ejectable.files,
        sourceBaseDir,
        ejectTargetDir,
        componentId,
        options.force
      );

      const transformedFiles = transformImportsInDir(
        baseTargetDir,
        ejectable.replaceImport.from,
        ejectTargetDir
      );

      console.log(`Created ${copyResult.created.length} files`);
      console.log(`Skipped ${copyResult.skipped.length} existing files`);
      console.log(`Transformed imports in ${transformedFiles} files`);
    });
}
