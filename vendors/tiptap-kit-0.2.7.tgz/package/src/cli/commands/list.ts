import type { Command } from "commander";
import { loadRegistry } from "../utils/resolve-registry";

const pad = (value: string, width: number) => value.padEnd(width, " ");

export function registerListCommand(program: Command): void {
  program.command("list").action(() => {
    const registry = loadRegistry();
    const templateEntries = Object.entries(registry.templates).sort(([a], [b]) =>
      a.localeCompare(b)
    );
    const ejectableEntries = Object.entries(registry.ejectables).sort(([a], [b]) =>
      a.localeCompare(b)
    );

    console.log("Templates:");
    for (const [id, manifest] of templateEntries) {
      console.log(`  ${pad(id, 20)} ${manifest.description}`);
    }

    console.log("");
    console.log("Ejectables:");
    for (const [id, manifest] of ejectableEntries) {
      console.log(`  ${pad(id, 20)} ${manifest.title}`);
    }
  });
}
