import fs from "fs";
import path from "path";
import type { Command } from "commander";
import { loadRegistry } from "../utils/resolve-registry";
import { copyTemplateFiles } from "../utils/copy-files";
import { installMissingDeps } from "../utils/install-deps";
import { findProjectRoot } from "../utils/find-project-root";

type AddCommandOptions = {
  target: string;
  force: boolean;
  skipInstall: boolean;
};

const resolveSourceBaseDir = () => {
  const candidates = [
    __dirname,
    path.resolve(__dirname, ".."),
    path.resolve(__dirname, "..", ".."),
    process.cwd()
  ];

  for (const candidate of candidates) {
    if (fs.existsSync(path.join(candidate, "templates"))) {
      return candidate;
    }
  }

  throw new Error("Cannot locate templates directory");
};

export function registerAddCommand(program: Command): void {
  program
    .command("add")
    .argument("<template>", "Template id")
    .option("-t, --target <dir>", "Target directory", "src/tiptap")
    .option("-f, --force", "Overwrite existing files", false)
    .option("--skip-install", "Skip dependency installation", false)
    .action((templateId: string, options: AddCommandOptions) => {
      const registry = loadRegistry();
      const template = registry.templates[templateId];

      if (!template) {
        const available = Object.keys(registry.templates).join(", ");
        console.error(`Unknown template: ${templateId}`);
        console.error(`Available templates: ${available}`);
        process.exit(1);
      }

      const sourceBaseDir = resolveSourceBaseDir();
      const targetDir = path.resolve(process.cwd(), options.target);

      const copyResult = copyTemplateFiles(
        template.files,
        sourceBaseDir,
        targetDir,
        templateId,
        options.force
      );

      console.log(`\nCreated ${copyResult.created.length} files`);
      if (copyResult.skipped.length > 0) {
        console.log(`Skipped ${copyResult.skipped.length} existing files`);
      }

      const projectRoot = findProjectRoot(targetDir);
      if (!projectRoot) {
        console.log("\nNo package.json found. Install dependencies manually:");
        const deps = Object.entries(template.dependencies)
          .map(([name, version]) => `${name}@${version}`)
          .join(" ");
        console.log(`  npm install ${deps}`);
      } else {
        installMissingDeps(template.dependencies, projectRoot, options.skipInstall);
      }

      console.log("\nImport styles: import '@ikame-lib/tiptap-kit/styles.css'");
    });
}
