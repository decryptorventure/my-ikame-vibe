export type TemplateManifest = {
  title: string;
  description: string;
  files: string[];
  dependencies: Record<string, string>;
};

export type EjectableManifest = {
  title: string;
  files: string[];
  targetDir: string;
  replaceImport: {
    from: string;
    to: string;
  };
};

export type Registry = {
  name: string;
  version: string;
  templates: Record<string, TemplateManifest>;
  ejectables: Record<string, EjectableManifest>;
};
