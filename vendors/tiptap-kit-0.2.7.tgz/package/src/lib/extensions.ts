import Placeholder from "@tiptap/extension-placeholder";
import Link from "@tiptap/extension-link";
import Underline from "@tiptap/extension-underline";
import StarterKit from "@tiptap/starter-kit";
import { AnyExtension } from "@tiptap/core";

export type BaseExtensionsOptions = {
  placeholder?: string;
  disableUnderline?: boolean;
  disableLink?: boolean;
};

export const createBaseExtensions = ({
  placeholder = "Start typing…",
  disableUnderline = false,
  disableLink = false
}: BaseExtensionsOptions = {}) => {
  const extensions: AnyExtension[] = [StarterKit.configure({ codeBlock: false }), Placeholder.configure({ placeholder })];

  if (!disableUnderline) {
    extensions.push(Underline);
  }

  if (!disableLink) {
    extensions.push(
      Link.configure({
        openOnClick: true,
        autolink: true,
        linkOnPaste: true
      })
    );
  }

  return extensions;
};

