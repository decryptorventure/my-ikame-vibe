// Legacy simple editor components (use deep imports for tiptap-ui components)
export * from "./editor/EditorShell";
export * from "./editor/FloatingBubble";
export * from "./editor/Toolbar";
export * from "./editor/ToolbarButton";

