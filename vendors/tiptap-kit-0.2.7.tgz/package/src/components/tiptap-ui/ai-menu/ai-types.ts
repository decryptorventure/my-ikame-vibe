export type Language = string
export type Tone = string

export type TextOptions = {
  tone?: Tone
  format?: "rich-text" | "plain-text" | string
  stream?: boolean
}

