"use client"

import { useCallback } from "react"
import type { Editor } from "@tiptap/react"
import { Button, ButtonGroup } from "@/components/tiptap-ui-primitive/button"
import { RefreshAiIcon } from "@/components/tiptap-icons/refresh-ai-icon"
import { XIcon } from "@/components/tiptap-icons/x-icon"
import { CheckIcon } from "@/components/tiptap-icons/check-icon"
import type { TextOptions } from "@/components/tiptap-ui/ai-menu/ai-types"
import { useUiEditorState } from "@/hooks/use-ui-editor-state"

import "@/components/tiptap-ui/ai-menu/ai-menu-actions/ai-menu-actions.scss"

const runChainCommand = (
  editor: Editor | null,
  commandKey: string,
  ...args: unknown[]
) => {
  if (!editor) return false
  const chain = editor.chain().focus() as Record<string, unknown>
  const command = chain[commandKey]
  if (typeof command !== "function") return false
  const result = (command as (...params: unknown[]) => unknown).apply(
    chain,
    args
  )
  if (
    result &&
    typeof (result as Record<string, unknown>).run === "function"
  ) {
    ;(result as { run: () => void }).run()
  }
  return true
}

export interface AiMenuActionsProps {
  editor: Editor | null
  options: TextOptions
  onRegenerate?: () => void
  onAccept?: () => void
  onReject?: () => void
}

export function AiMenuActions({
  editor,
  options,
  onRegenerate,
  onAccept,
  onReject,
}: AiMenuActionsProps) {
  const { aiGenerationIsLoading } = useUiEditorState(editor)

  const handleRegenerate = useCallback(() => {
    runChainCommand(editor, "aiRegenerate", options)
    onRegenerate?.()
  }, [editor, onRegenerate, options])

  const handleDiscard = useCallback(() => {
    runChainCommand(editor, "aiReject")
    onReject?.()
  }, [editor, onReject])

  const handleApply = useCallback(() => {
    runChainCommand(editor, "aiAccept")
    onAccept?.()
  }, [editor, onAccept])

  return (
    <div className="tiptap-ai-menu-actions">
      <div className="tiptap-ai-menu-results">
        <ButtonGroup orientation="horizontal">
          <Button
            data-style="ghost"
            className="tiptap-button"
            onClick={handleRegenerate}
            disabled={aiGenerationIsLoading}
          >
            <RefreshAiIcon className="tiptap-button-icon" />
            Try again
          </Button>
        </ButtonGroup>
      </div>

      <div className="tiptap-ai-menu-commit">
        <ButtonGroup orientation="horizontal">
          <Button
            data-style="ghost"
            className="tiptap-button"
            onClick={handleDiscard}
          >
            <XIcon className="tiptap-button-icon" />
            Discard
          </Button>
          <Button
            data-style="primary"
            className="tiptap-button"
            onClick={handleApply}
          >
            <CheckIcon className="tiptap-button-icon" />
            Apply
          </Button>
        </ButtonGroup>
      </div>
    </div>
  )
}
