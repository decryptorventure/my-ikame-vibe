import { useCallback, useEffect, useRef } from "react"
import { type Editor } from "@tiptap/react"

import { AiMenuItems } from "@/components/tiptap-ui/ai-menu/ai-menu-items/ai-menu-items"

// -- Hooks --
import { useTiptapEditor } from "@/hooks/use-tiptap-editor"
import { useUiEditorState } from "@/hooks/use-ui-editor-state"

// -- Utils --
import {
  getSelectedDOMElement,
  selectionHasText,
} from "@/lib/tiptap-advanced-utils"

// -- Tiptap UI --
import { AiMenuInputTextarea } from "@/components/tiptap-ui/ai-menu/ai-menu-input/ai-menu-input"
import { AiMenuActions } from "@/components/tiptap-ui/ai-menu/ai-menu-actions/ai-menu-actions"

// -- UI Primitives --
import {
  Menu,
  MenuContent,
  useFloatingMenuStore,
} from "@/components/tiptap-ui-primitive/menu"
import { Button, ButtonGroup } from "@/components/tiptap-ui-primitive/button"
import {
  ComboboxList,
  ComboboxPopover,
} from "@/components/tiptap-ui-primitive/combobox"
import { Card } from "@/components/tiptap-ui-primitive/card/card"

import { getContextAndInsertAt } from "@/components/tiptap-ui/ai-menu/ai-menu-utils"
import {
  useAiContentTracker,
  useAiMenuState,
  useAiMenuStateProvider,
  useTextSelectionTracker,
} from "@/components/tiptap-ui/ai-menu/ai-menu-hooks"

// -- Icons --
import { StopCircle2Icon } from "@/components/tiptap-icons/stop-circle-2-icon"

import "@/components/tiptap-ui/ai-menu/ai-menu.scss"

const runChainCommand = (
  editor: Editor | null,
  commandKey: string,
  ...args: unknown[]
) => {
  if (!editor) return false
  const chain = editor.chain().focus() as Record<string, unknown>
  const command = chain[commandKey]

  if (typeof command !== "function") return false

  const result = (command as (...params: unknown[]) => unknown).apply(
    chain,
    args
  )

  if (
    result &&
    typeof (result as Record<string, unknown>).run === "function"
  ) {
    ;(result as { run: () => void }).run()
  }

  return true
}

const runCommand = (
  editor: Editor | null,
  commandKey: string,
  ...args: unknown[]
) => {
  if (!editor) return false
  const command = (editor.commands as Record<string, unknown>)[commandKey]
  if (typeof command !== "function") return false
  ;(command as (...params: unknown[]) => void).apply(null, args)
  return true
}

export function AiMenuStateProvider({
  children,
}: {
  children: React.ReactNode
}) {
  const { value, AiMenuStateContext } = useAiMenuStateProvider()

  return (
    <AiMenuStateContext.Provider value={value}>
      {children}
    </AiMenuStateContext.Provider>
  )
}

export function AiMenuContent({
  editor: providedEditor,
}: {
  editor?: Editor | null
}) {
  const { editor } = useTiptapEditor(providedEditor)
  const { state, updateState, setFallbackAnchor, reset } = useAiMenuState()
  const { show, store } = useFloatingMenuStore()
  const { aiGenerationIsLoading, aiGenerationActive, aiGenerationHasMessage } =
    useUiEditorState(editor)
  const tiptapAiPromptInputRef = useRef<HTMLDivElement | null>(null)

  const closeAiMenu = useCallback(() => {
    if (!editor) return
    reset()
    store?.hideAll()
    runCommand(editor, "resetUiState")
  }, [editor, reset, store])

  const handlePromptSubmit = useCallback(
    (userPrompt: string) => {
      if (!editor || !userPrompt.trim()) return

      const { context } = getContextAndInsertAt(editor)
      // if context, add it to the user prompt
      const promptWithContext = context
        ? `${context}\n\n${userPrompt}`
        : userPrompt

      // Ensure fallback anchor is set before submitting
      if (!state.fallbackAnchor.element || !state.fallbackAnchor.rect) {
        const currentSelectedElement = getSelectedDOMElement(editor)
        if (currentSelectedElement) {
          const rect = currentSelectedElement.getBoundingClientRect()
          setFallbackAnchor(currentSelectedElement, rect)
        }
      }

      runChainCommand(editor, "aiTextPrompt", {
        text: promptWithContext,
        insert: true,
        stream: true,
        tone: state.tone,
        format: "rich-text",
      })
    },
    [editor, state.tone, state.fallbackAnchor, setFallbackAnchor]
  )

  const setAnchorElement = useCallback(
    (element: HTMLElement) => {
      store.setAnchorElement(element)
    },
    [store]
  )

  const handleSelectionChange = useCallback(
    (element: HTMLElement | null, rect: DOMRect | null) => {
      setFallbackAnchor(element, rect)
    },
    [setFallbackAnchor]
  )

  const handleOnReject = useCallback(() => {
    runCommand(editor, "aiReject")
    closeAiMenu()
  }, [closeAiMenu, editor])

  const handleOnAccept = useCallback(() => {
    runCommand(editor, "aiAccept")
    closeAiMenu()
  }, [closeAiMenu, editor])

  const handleInputOnClose = useCallback(() => {
    if (aiGenerationIsLoading) {
      runCommand(editor, "aiReject", { type: "reset" })
    } else {
      runCommand(editor, "aiAccept")
    }
    closeAiMenu()
  }, [aiGenerationIsLoading, closeAiMenu, editor])

  const handleClickOutside = useCallback(() => {
    if (!aiGenerationIsLoading) {
      closeAiMenu()

      runCommand(editor, "aiAccept")
    }
  }, [aiGenerationIsLoading, closeAiMenu, editor])

  useAiContentTracker({
    editor,
    aiGenerationActive,
    setAnchorElement,
    fallbackAnchor: state.fallbackAnchor,
  })

  useTextSelectionTracker({
    editor,
    aiGenerationActive,
    showMenuAtElement: show,
    setMenuVisible: (visible) => updateState({ isOpen: visible }),
    onSelectionChange: handleSelectionChange,
    prevent: aiGenerationIsLoading,
  })

  useEffect(() => {
    if (aiGenerationIsLoading) {
      updateState({ shouldShowInput: false })
    }
  }, [aiGenerationIsLoading, updateState])

  useEffect(() => {
    if (aiGenerationHasMessage && !aiGenerationIsLoading && editor) {
      const storage = editor.storage as unknown as Record<string, unknown>
      const aiStorage = (storage.ai || storage.aiAdvanced) as
        | { generatedWith?: { range?: { from: number; to: number } } }
        | undefined
      const range = aiStorage?.generatedWith?.range

      if (range) {
        try {
          const clampedPos = Math.min(range.to, editor.state.doc.content.size)
          const domAtPos = editor.view.domAtPos(clampedPos)
          const element =
            domAtPos.node instanceof HTMLElement
              ? domAtPos.node
              : domAtPos.node.parentElement

          if (element && element !== editor.view.dom) {
            store.setAnchorElement(element)
          }
        } catch {
          // pos may be out of range
        }
      }
    }
  }, [aiGenerationHasMessage, aiGenerationIsLoading])

  useEffect(() => {
    if (aiGenerationActive && !state.isOpen && editor) {
      const selectedElement = getSelectedDOMElement(editor)
      if (selectedElement) {
        show(selectedElement)
        setFallbackAnchor(selectedElement, selectedElement.getBoundingClientRect())
      }
      updateState({ isOpen: true })
    }
  }, [aiGenerationActive])

  useEffect(() => {
    if (!aiGenerationActive && state.isOpen) {
      closeAiMenu()
    }
  }, [aiGenerationActive, state.isOpen, closeAiMenu])

  const smoothFocusAndScroll = (element: HTMLElement | null) => {
    element?.focus()
    element?.scrollIntoView({
      behavior: "smooth",
      block: "center",
      inline: "nearest",
    })

    // Ensure the menu back to focus after focusing on the popover
    setTimeout(() => store.setAutoFocusOnShow(false), 0)
    return false
  }

  const shouldShowList =
    selectionHasText(editor) ||
    (aiGenerationHasMessage && state.shouldShowInput && state.inputIsFocused)

  if (!editor || !state.isOpen || !aiGenerationActive) {
    return null
  }

  return (
    <Menu open={state.isOpen} placement="bottom-start" store={store}>
      <MenuContent
        onClickOutside={handleClickOutside}
        className="tiptap-ai-menu"
        flip={false}
      >
        <Card>
          {aiGenerationIsLoading && <AiMenuProgress editor={editor} />}

          {!aiGenerationIsLoading && (
            <AiMenuInputTextarea
              ref={tiptapAiPromptInputRef}
              showPlaceholder={
                !aiGenerationIsLoading &&
                aiGenerationHasMessage &&
                !state.shouldShowInput
              }
              onInputFocus={() => updateState({ inputIsFocused: true })}
              onInputBlur={() => updateState({ inputIsFocused: false })}
              onClose={handleInputOnClose}
              onPlaceholderClick={() => updateState({ shouldShowInput: true })}
              onInputSubmit={(value) => handlePromptSubmit(value)}
              onToneChange={(tone) => updateState({ tone })}
            />
          )}

          {aiGenerationHasMessage && !aiGenerationIsLoading && (
            <AiMenuActions
              editor={editor}
              options={{ tone: state.tone, format: "rich-text" }}
              onAccept={handleOnAccept}
              onReject={handleOnReject}
            />
          )}
        </Card>

        {!aiGenerationIsLoading && (
          <ComboboxPopover
            flip={false}
            unmountOnHide
            autoFocus={false}
            onFocus={() => updateState({ inputIsFocused: true })}
            autoFocusOnShow={smoothFocusAndScroll}
            autoFocusOnHide={smoothFocusAndScroll}
            getAnchorRect={() => {
              return (
                tiptapAiPromptInputRef.current?.getBoundingClientRect() || null
              )
            }}
          >
            <ComboboxList
              style={{ display: shouldShowList ? "block" : "none" }}
            >
              <AiMenuItems />
            </ComboboxList>
          </ComboboxPopover>
        )}
      </MenuContent>
    </Menu>
  )
}

export function AiMenuProgress({ editor }: { editor: Editor }) {
  const { reset } = useAiMenuState()

  const handleStop = useCallback(() => {
    runChainCommand(editor, "aiReject", { type: "reset" })
    reset()
    runCommand(editor, "resetUiState")
  }, [editor, reset])

  return (
    <div className="tiptap-ai-menu-progress">
      <div className="tiptap-spinner-alt">
        <span>AI is writing</span>
        <div className="dots-container">
          <div className="dot"></div>
          <div className="dot"></div>
          <div className="dot"></div>
        </div>
      </div>

      <ButtonGroup>
        <Button data-style="ghost" title="Stop" onClick={handleStop}>
          <StopCircle2Icon className="tiptap-button-icon" />
        </Button>
      </ButtonGroup>
    </div>
  )
}

export function AiMenu({ editor }: { editor?: Editor | null }) {
  return (
    <AiMenuStateProvider>
      <AiMenuContent editor={editor} />
    </AiMenuStateProvider>
  )
}
