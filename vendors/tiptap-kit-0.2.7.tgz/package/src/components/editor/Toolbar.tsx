import { Editor } from "@tiptap/react";
import { ToolbarButton } from "./ToolbarButton";

export type ToolbarAction = {
  id: string;
  label: string;
  run: (editor: Editor) => void;
  isActive?: (editor: Editor) => boolean;
  isDisabled?: (editor: Editor) => boolean;
};

type ToolbarProps = {
  editor: Editor | null;
  actions?: ToolbarAction[];
};

const buildDefaultActions = (): ToolbarAction[] => [
  {
    id: "bold",
    label: "Bold",
    run: (editor) => editor.chain().focus().toggleBold().run(),
    isActive: (editor) => editor.isActive("bold")
  },
  {
    id: "italic",
    label: "Italic",
    run: (editor) => editor.chain().focus().toggleItalic().run(),
    isActive: (editor) => editor.isActive("italic")
  },
  {
    id: "underline",
    label: "Underline",
    run: (editor) => editor.chain().focus().toggleUnderline().run(),
    isActive: (editor) => editor.isActive("underline")
  },
  {
    id: "strike",
    label: "Strike",
    run: (editor) => editor.chain().focus().toggleStrike().run(),
    isActive: (editor) => editor.isActive("strike")
  },
  {
    id: "bulletList",
    label: "Bullet",
    run: (editor) => editor.chain().focus().toggleBulletList().run(),
    isActive: (editor) => editor.isActive("bulletList")
  },
  {
    id: "orderedList",
    label: "Numbered",
    run: (editor) => editor.chain().focus().toggleOrderedList().run(),
    isActive: (editor) => editor.isActive("orderedList")
  },
  {
    id: "blockquote",
    label: "Quote",
    run: (editor) => editor.chain().focus().toggleBlockquote().run(),
    isActive: (editor) => editor.isActive("blockquote")
  },
  {
    id: "undo",
    label: "Undo",
    run: (editor) => editor.chain().focus().undo().run(),
    isDisabled: (editor) => !editor.can().undo()
  },
  {
    id: "redo",
    label: "Redo",
    run: (editor) => editor.chain().focus().redo().run(),
    isDisabled: (editor) => !editor.can().redo()
  }
];

export const Toolbar = ({ editor, actions }: ToolbarProps) => {
  if (!editor) return null;

  const resolvedActions = actions ?? buildDefaultActions();

  return (
    <div className="tiptap-toolbar" role="toolbar" aria-label="Editor toolbar">
      {resolvedActions.map((action) => (
        <ToolbarButton
          key={action.id}
          label={action.label}
          isActive={action.isActive ? action.isActive(editor) : false}
          disabled={action.isDisabled ? action.isDisabled(editor) : false}
          onClick={() => action.run(editor)}
        />
      ))}
    </div>
  );
};

