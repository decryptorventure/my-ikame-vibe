import { EditorContent, Editor } from "@tiptap/react";
import { ReactNode } from "react";
import { EditorProvider } from "../../contexts/EditorContext";
import { FloatingBubble } from "./FloatingBubble";
import { Toolbar, ToolbarAction } from "./Toolbar";

type EditorShellProps = {
  editor: Editor | null;
  toolbarActions?: ToolbarAction[];
  renderAbove?: ReactNode;
  renderBelow?: ReactNode;
  className?: string;
  showBubble?: boolean;
};

export const EditorShell = ({
  editor,
  toolbarActions,
  renderAbove,
  renderBelow,
  className = "",
  showBubble = true
}: EditorShellProps) => {
  if (!editor) return null;

  return (
    <div className={`tt-editor ${className}`}>
      {renderAbove}
      <EditorProvider editor={editor}>
        <Toolbar editor={editor} actions={toolbarActions} />
        <div className="tt-editor__body">
          <EditorContent editor={editor} className="tt-editor__content" aria-label="Rich text editor" />
          {showBubble ? <FloatingBubble editor={editor} /> : null}
        </div>
      </EditorProvider>
      {renderBelow}
    </div>
  );
};

