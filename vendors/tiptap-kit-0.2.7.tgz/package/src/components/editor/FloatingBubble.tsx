// @ts-nocheck
import { Editor } from "@tiptap/react";
import { BubbleMenu } from "@tiptap/react/menus";
import { useFloatingToolbarVisibility } from "../../hooks/use-floating-toolbar-visibility";
import { ToolbarButton } from "./ToolbarButton";

type FloatingBubbleProps = {
  editor: Editor | null;
};

export const FloatingBubble = ({ editor }: FloatingBubbleProps) => {
  const { shouldShow } = useFloatingToolbarVisibility({
    editor,
    isSelectionValid: (ed, sel) => ed.isFocused && !sel.empty,
  });
  if (!editor || !shouldShow) return null;

  return (
    <BubbleMenu editor={editor} className="tt-bubble">
      <ToolbarButton
        label="Bold"
        isActive={editor.isActive("bold")}
        onClick={() => editor.chain().focus().toggleBold().run()}
      />
      <ToolbarButton
        label="Italic"
        isActive={editor.isActive("italic")}
        onClick={() => editor.chain().focus().toggleItalic().run()}
      />
      <ToolbarButton
        label="Link"
        onClick={() => {
          const previousUrl = editor.getAttributes("link").href;
          const url = window.prompt("Set link URL", previousUrl || "https://");
          if (!url) return;
          editor.chain().focus().extendMarkRange("link").setLink({ href: url }).run();
        }}
      />
    </BubbleMenu>
  );
};

