import { ButtonHTMLAttributes, ReactNode } from "react";

type ToolbarButtonProps = {
  label: string;
  icon?: ReactNode;
  isActive?: boolean;
  onClick?: ButtonHTMLAttributes<HTMLButtonElement>["onClick"];
  disabled?: boolean;
};

export const ToolbarButton = ({ label, icon, isActive = false, onClick, disabled = false }: ToolbarButtonProps) => {
  return (
    <button
      type="button"
      className="tiptap-button"
      data-highlighted={isActive || undefined}
      aria-label={label}
      disabled={disabled}
      onClick={onClick}
    >
      <span className="tiptap-button-icon" aria-hidden="true">
        {icon ?? label.charAt(0)}
      </span>
      <span className="tiptap-button-text">{label}</span>
    </button>
  );
};

