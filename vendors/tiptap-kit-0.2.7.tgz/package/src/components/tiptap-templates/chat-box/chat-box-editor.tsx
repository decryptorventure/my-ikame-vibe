"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import { EditorContent, EditorContext, useEditor, type JSONContent } from "@tiptap/react"

// --- Tiptap Core Extensions ---
import { StarterKit } from "@tiptap/starter-kit"
import { Mention } from "@tiptap/extension-mention"
import { Placeholder } from "@tiptap/extensions"
import { Selection } from "@tiptap/extensions"
import { Emoji, gitHubEmojis } from "@tiptap/extension-emoji"
import { Image } from "@tiptap/extension-image"
import { Highlight } from "@tiptap/extension-highlight"

// --- UI Primitives ---
import { Button } from "@/components/tiptap-ui-primitive/button"
import {
  Toolbar,
  ToolbarGroup,
  ToolbarSeparator,
} from "@/components/tiptap-ui-primitive/toolbar"

// --- Tiptap Node ---
import { ImageUploadNode } from "@/components/tiptap-node/image-upload-node/image-upload-node-extension"

// --- Tiptap UI ---
import { MarkButton } from "@/components/tiptap-ui/mark-button"
import { LinkPopover } from "@/components/tiptap-ui/link-popover"
import { ListDropdownMenu } from "@/components/tiptap-ui/list-dropdown-menu"
import { BlockquoteButton } from "@/components/tiptap-ui/blockquote-button"
import { CodeBlockButton } from "@/components/tiptap-ui/code-block-button"
import { ImageUploadButton } from "@/components/tiptap-ui/image-upload-button"
import { EmojiDropdownMenu } from "@/components/tiptap-ui/emoji-dropdown-menu"
import { MentionDropdownMenu } from "@/components/tiptap-ui/mention-dropdown-menu"

// --- Icons ---
import { ImageIcon } from "@/components/tiptap-icons/image-icon"
import { SmilePlusIcon } from "@/components/tiptap-icons/smile-plus-icon"

// --- Lib ---
import { handleImageUpload, MAX_FILE_SIZE } from "@/lib/tiptap-utils"

// --- Styles ---
import "@/components/tiptap-templates/chat-box/chat-box-editor.css"

import content from "@/components/tiptap-templates/chat-box/data/content.json"

export interface ChatBoxEditorProps {
  placeholder?: string
  onSend?: (content: { json: JSONContent; html: string; text: string }) => void
  toolbar?: boolean
  emoji?: boolean
  imageUpload?: boolean
  mention?: boolean
}

export function ChatBoxEditor({
  placeholder = "Type a message...",
  onSend,
  toolbar = false,
  emoji = true,
  imageUpload = true,
  mention = true,
}: ChatBoxEditorProps) {
  const [isCollapsed, setIsCollapsed] = useState(true)
  const [hasContent, setHasContent] = useState(false)
  const wrapperRef = useRef<HTMLDivElement>(null)
  const handleSendRef = useRef<() => void>(() => {})
  const isSuggestionMenuOpenRef = useRef<() => boolean>(() => false)

  const suggestionSelector = [
    mention ? '[data-selector="tiptap-mention-dropdown-menu"]' : null,
    emoji ? '[data-selector="tiptap-emoji-dropdown-menu"]' : null,
  ]
    .filter(Boolean)
    .join(", ")

  const getSuggestionMenus = useCallback(() => {
    if (!suggestionSelector) {
      return []
    }

    return Array.from(document.querySelectorAll<HTMLElement>(suggestionSelector))
  }, [suggestionSelector])

  const isSuggestionMenuOpen = useCallback(() => {
    return getSuggestionMenus().length > 0
  }, [getSuggestionMenus])

  // Sync refs de tranh stale closure trong handleKeyDown
  useEffect(() => {
    isSuggestionMenuOpenRef.current = isSuggestionMenuOpen
  }, [isSuggestionMenuOpen])

  const isSuggestionMenuTarget = useCallback(
    (target: EventTarget | null) => {
      if (!(target instanceof Node)) {
        return false
      }

      return getSuggestionMenus().some((menu) => menu.contains(target))
    },
    [getSuggestionMenus]
  )

  const editor = useEditor({
    immediatelyRender: false,
    editorProps: {
      attributes: {
        autocomplete: "off",
        autocorrect: "off",
        autocapitalize: "off",
        "aria-label": "Chat message input",
        class: "chat-box-editor",
      },
      handleKeyDown: (_view, event) => {
        if (
          event.key === "Enter" &&
          !event.shiftKey &&
          !event.metaKey &&
          !event.ctrlKey
        ) {
          if (isSuggestionMenuOpenRef.current()) {
            return false
          }

          event.preventDefault()
          handleSendRef.current()
          return true
        }

        return false
      },
    },
    extensions: [
      StarterKit.configure({
        horizontalRule: false,
        heading: toolbar ? {} : false,
        codeBlock: toolbar ? {} : false,
        blockquote: toolbar ? {} : false,
        link: {
          openOnClick: false,
          enableClickSelection: true,
        },
      }),
      Placeholder.configure({ placeholder }),
      Selection,
      Highlight.configure({ multicolor: true }),
      ...(mention ? [Mention] : []),
      ...(emoji
        ? [
            Emoji.configure({
              emojis: gitHubEmojis.filter(
                (item) => !item.name.includes("regional")
              ),
              forceFallbackImages: true,
            }),
          ]
        : []),
      ...(imageUpload
        ? [
            Image,
            ImageUploadNode.configure({
              accept: "image/*",
              maxSize: MAX_FILE_SIZE,
              limit: 3,
              upload: handleImageUpload,
              onError: (error: unknown) => console.error("Upload failed:", error),
            }),
          ]
        : []),
    ],
    content,
    onUpdate: ({ editor }) => {
      setHasContent(!editor.isEmpty)
    },
  })

  const handleSend = useCallback(() => {
    if (!editor || editor.isEmpty) {
      return
    }

    onSend?.({
      json: editor.getJSON(),
      html: editor.getHTML(),
      text: editor.getText(),
    })

    editor.commands.clearContent(true)
    editor.commands.blur()
    setHasContent(false)
    setIsCollapsed(true)
  }, [editor, onSend])

  useEffect(() => {
    handleSendRef.current = handleSend
  }, [handleSend])

  const handleFocus = useCallback(() => {
    setIsCollapsed(false)
  }, [])

  const handleBlur = useCallback(() => {
    if (!editor) {
      return
    }

    requestAnimationFrame(() => {
      if (wrapperRef.current?.contains(document.activeElement)) {
        return
      }

      if (isSuggestionMenuTarget(document.activeElement)) {
        return
      }

      if (editor.isEmpty) {
        setIsCollapsed(true)
      }
    })
  }, [editor, isSuggestionMenuTarget])

  useEffect(() => {
    if (!editor) {
      return
    }

    setHasContent(!editor.isEmpty)
  }, [editor])

  useEffect(() => {
    if (!editor) {
      return
    }

    const handleClickOutside = (event: MouseEvent) => {
      if (wrapperRef.current?.contains(event.target as Node)) {
        return
      }

      if (isSuggestionMenuTarget(event.target)) {
        return
      }

      if (editor.isEmpty) {
        setIsCollapsed(true)
        editor.commands.blur()
      }
    }

    document.addEventListener("mousedown", handleClickOutside)

    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [editor, isSuggestionMenuTarget])

  return (
    <div
      ref={wrapperRef}
      className="chat-box-wrapper"
      data-collapsed={isCollapsed}
    >
      <EditorContext.Provider value={{ editor }}>
        {toolbar && !isCollapsed && (
          <Toolbar className="chat-box-toolbar">
            <ToolbarGroup>
              <MarkButton type="bold" />
              <MarkButton type="italic" />
              <MarkButton type="underline" />
              <MarkButton type="strike" />
              <LinkPopover />
            </ToolbarGroup>

            <ToolbarSeparator />

            <ToolbarGroup>
              <ListDropdownMenu types={["bulletList", "orderedList"]} />
            </ToolbarGroup>

            <ToolbarSeparator />

            <ToolbarGroup>
              <CodeBlockButton />
              <BlockquoteButton />
            </ToolbarGroup>
          </Toolbar>
        )}

        <div className="chat-box-inner">
          <EditorContent
            editor={editor}
            role="presentation"
            className="chat-box-editor-content"
            onFocus={handleFocus}
            onBlur={handleBlur}
          >
            {mention && <MentionDropdownMenu />}
            {emoji && <EmojiDropdownMenu />}
          </EditorContent>

          <div className="chat-box-bottom-bar">
            <div className="chat-box-bottom-actions">
              {emoji && (
                <Button
                  type="button"
                  data-style="ghost"
                  onClick={() => {
                    setIsCollapsed(false)
                    editor?.chain().focus().insertContent(":").run()
                  }}
                  aria-label="Emoji"
                >
                  <SmilePlusIcon className="tiptap-button-icon" />
                </Button>
              )}

              {imageUpload && <ImageUploadButton icon={ImageIcon} />}
            </div>

            <button
              type="button"
              className="chat-box-send-button"
              data-has-content={hasContent}
              onClick={handleSend}
              disabled={!hasContent}
              aria-label="Send message"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M22 2L11 13" />
                <path d="M22 2L15 22L11 13L2 9L22 2Z" />
              </svg>
            </button>
          </div>
        </div>
      </EditorContext.Provider>
    </div>
  )
}
