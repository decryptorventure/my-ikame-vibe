"use client"

import type { NodeViewProps } from "@tiptap/react"
import { NodeViewWrapper } from "@tiptap/react"
import { useToc } from "@/components/tiptap-node/toc-node/context/toc-context"
import "@/components/tiptap-node/toc-node/toc-node.scss"

function scrollToHeading(id: string) {
  const element = document.querySelector<HTMLElement>(`[data-toc-id="${id}"]`)
    || document.getElementById(id)
  if (element) {
    element.scrollIntoView({ behavior: "smooth", block: "start" })

    setTimeout(() => {
      element.animate(
        [
          { backgroundColor: "rgba(59, 130, 246, 0.25)", borderRadius: "0.25rem", offset: 0 },
          { backgroundColor: "rgba(59, 130, 246, 0.25)", borderRadius: "0.25rem", offset: 0.3 },
          { backgroundColor: "transparent", borderRadius: "0.25rem", offset: 1 },
        ],
        { duration: 1500, easing: "ease-out" }
      )
    }, 450)
  }
}

export function TocNodeView({ node }: NodeViewProps) {
  const { tocContent, showTitle } = useToc()
  const { maxShowCount } = node.attrs
  const items = maxShowCount ? tocContent.slice(0, maxShowCount) : tocContent

  return (
    <NodeViewWrapper className="tiptap-table-of-contents-node" contentEditable={false}>
      {showTitle && (
        <div className="tiptap-table-of-contents-title">Table of contents</div>
      )}
      {items.length === 0 ? (
        <div className="tiptap-table-of-contents-empty">
          Add headings to your document to see them here
        </div>
      ) : (
        <ul className="tiptap-table-of-contents-list">
          {items.map((item) => (
            <li
              key={item.id}
              className={[
                "tiptap-table-of-contents-item",
                item.isActive ? "is-active" : "",
                item.isScrolledOver ? "is-scrolled-over" : "",
              ]
                .filter(Boolean)
                .join(" ")}
              data-depth={item.depth}
            >
              <a
                href={`#${item.id}`}
                onClick={(e) => {
                  e.preventDefault()
                  scrollToHeading(item.id)
                }}
              >
                {item.text}
              </a>
            </li>
          ))}
        </ul>
      )}
    </NodeViewWrapper>
  )
}

