import { createContext, useContext, useState, type ReactNode } from "react"

export interface TocItem {
  id: string
  level: number
  text: string
  pos: number
  depth: number
  isScrolledOver?: boolean
  isActive?: boolean
}

interface TocContextValue {
  tocContent: TocItem[]
  setTocContent: (content: TocItem[]) => void
  showTitle: boolean
  setShowTitle: (show: boolean) => void
}

const TocContext = createContext<TocContextValue | null>(null)

export function TocProvider({ children }: { children: ReactNode }) {
  const [tocContent, setTocContent] = useState<TocItem[]>([])
  const [showTitle, setShowTitle] = useState(true)

  return (
    <TocContext.Provider value={{ tocContent, setTocContent, showTitle, setShowTitle }}>
      {children}
    </TocContext.Provider>
  )
}

export function useToc() {
  const context = useContext(TocContext)
  if (!context) {
    throw new Error("useToc must be used within TocProvider")
  }
  return context
}

export function useTocShowTitle() {
  const { showTitle, setShowTitle } = useToc()
  return { showTitle, setShowTitle }
}
