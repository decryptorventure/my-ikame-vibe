"use client"

import { useToc } from "@/components/tiptap-node/toc-node/context/toc-context"
import "@/components/tiptap-node/toc-node/ui/toc-sidebar/toc-sidebar.scss"

interface TocSidebarProps {
  maxShowCount?: number
  topOffset?: number
}

function scrollToHeading(id: string) {
  const element = document.querySelector<HTMLElement>(`[data-toc-id="${id}"]`)
    || document.getElementById(id)
  if (element) {
    element.scrollIntoView({ behavior: "smooth", block: "start" })

    setTimeout(() => {
      element.animate(
        [
          { backgroundColor: "rgba(59, 130, 246, 0.25)", borderRadius: "0.25rem", offset: 0 },
          { backgroundColor: "rgba(59, 130, 246, 0.25)", borderRadius: "0.25rem", offset: 0.3 },
          { backgroundColor: "transparent", borderRadius: "0.25rem", offset: 1 },
        ],
        { duration: 1500, easing: "ease-out" }
      )
    }, 450)
  }
}

export function TocSidebar({ maxShowCount = 50, topOffset = 80 }: TocSidebarProps) {
  const { tocContent } = useToc()
  const items = maxShowCount ? tocContent.slice(0, maxShowCount) : tocContent

  if (items.length === 0) {
    return null
  }

  return (
    <aside className="toc-sidebar">
      <div className="toc-sidebar-title">On this page</div>
      <ul className="toc-sidebar-list">
        {items.map((item) => (
          <li
            key={item.id}
            className={[
              "toc-sidebar-item",
              item.isActive ? "is-active" : "",
              item.isScrolledOver ? "is-scrolled-over" : "",
            ]
              .filter(Boolean)
              .join(" ")}
            data-depth={item.depth}
          >
            <a
              href={`#${item.id}`}
              onClick={(e) => {
                e.preventDefault()
                scrollToHeading(item.id)
              }}
            >
              {item.text}
            </a>
          </li>
        ))}
      </ul>
    </aside>
  )
}

