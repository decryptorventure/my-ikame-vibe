import { createContext, ReactNode, useContext } from "react";
import { Editor } from "@tiptap/react";

type EditorContextValue = {
  editor: Editor | null;
  isEditable: boolean;
};

const EditorContext = createContext<EditorContextValue>({
  editor: null,
  isEditable: false
});

type EditorProviderProps = {
  editor: Editor | null;
  isEditable?: boolean;
  children: ReactNode;
};

export const EditorProvider = ({ editor, isEditable = true, children }: EditorProviderProps) => {
  if (!editor) return null;

  return (
    <EditorContext.Provider
      value={{
        editor,
        isEditable
      }}
    >
      {children}
    </EditorContext.Provider>
  );
};

export const useEditorContext = () => {
  const context = useContext(EditorContext);
  if (!context) {
    throw new Error("useEditorContext must be used within EditorProvider");
  }
  return context;
};

