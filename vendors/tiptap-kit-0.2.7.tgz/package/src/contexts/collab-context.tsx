import { createContext, useContext, useMemo, useState } from "react"
import { Doc as YDoc } from "yjs"

export type CollabContextValue = {
  provider: null
  ydoc: YDoc
  hasCollab: boolean
}

export const CollabContext = createContext<CollabContextValue>({
  hasCollab: false,
  provider: null,
  ydoc: new YDoc(),
})

export const CollabConsumer = CollabContext.Consumer
export const useCollab = (): CollabContextValue => {
  const context = useContext(CollabContext)
  if (!context) {
    throw new Error("useCollab must be used within an CollabProvider")
  }
  return context
}

export const useCollaboration = (_room: string) => {
  const [provider] = useState<null>(null)
  const [hasCollab] = useState<boolean>(false)
  const ydoc = useMemo(() => new YDoc(), [])

  return { provider, ydoc, hasCollab }
}

export function CollabProvider({
  children,
  room: _room,
}: Readonly<{
  children: React.ReactNode
  room: string
}>) {
  const { hasCollab, provider, ydoc } = useCollaboration(_room)

  const value = useMemo<CollabContextValue>(
    () => ({
      hasCollab,
      provider,
      ydoc,
    }),
    [hasCollab, provider, ydoc]
  )

  return (
    <CollabContext.Provider value={value}>{children}</CollabContext.Provider>
  )
}
